package com.example.feelfit

class itemview2(val imageG : Int, val image2 : Int ,var text: String )

{
}