package com.example.feelfit

data class Users(
    val name:String? = null,
    val email:String? = null,
    val pass:String? = null
)
{

}
