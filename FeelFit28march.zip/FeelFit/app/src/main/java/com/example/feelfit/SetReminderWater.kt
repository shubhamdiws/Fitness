package com.example.feelfit

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class SetReminderWater : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_set_reminder_water)
    }
}