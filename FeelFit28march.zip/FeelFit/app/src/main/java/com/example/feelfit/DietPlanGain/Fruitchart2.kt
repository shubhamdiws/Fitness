package com.example.feelfit.DietPlanGain

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.feelfit.R

class fruitchart2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fruitchart2)
    }
}