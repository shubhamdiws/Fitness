package com.example.feelfit

class itemview3(val imageN: Int, val image3: Int, var text: String)

{
}